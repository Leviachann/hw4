#include <iostream>
using namespace std;
//prototiplerini yazdim tapsiriqlarin cunki deqiq ne olacagini basa dusmedim
class mystr
char* firstobj(char* array){
  return array[0];
}
char* lastobj(char* array){
  return array[strlen-1];
}
char* append(const char* text){
char *all = new[strlen(part1)+strlen(text)+1];
strcpy(all,part1);
strcat(all,text);
}
int rfindd(char*array,char*a){
  return array.rfind(a);
}
int findd(char*array,char*w){
  return array.rfind(w);
}
void main() {
	Vector<Book, 2> books;
}