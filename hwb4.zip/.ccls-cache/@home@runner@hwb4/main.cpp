#include <iostream>
using namespace std;
// prototiplerini yazdim tapsiriqlarin cunki deqiq ne olacagini basa dusmedim
class MyStr {
  char firstobj(char *array, int size) { return array[0]; }
  char *lastobj(char *array) { return array[strlen - 1]; }
  char *append(const char *text, const char *part1) {
    char *all = new[strlen(part1) + strlen(text) + 1];
    strcpy(all, part1);
    strcat(all, text);
  }
  int rfindd(char *array, char *a) { return array.rfind(a); }
  int findd(char *array, char *w) { return array.rfind(w); }
};
class IntArray {
  int array, size;

public:
  IntArray(int arr, int ssize) {
    SetArray(arr);
    SetSize(ssize);
  }
  IntArray(int arr) {
    SetSize(10);
    SetArray(arr);
  }
  IntArray() {
    size = 10;
    int arr = [ 1, 2, 3, 4, 5 ];
  }
  void printingarray(int arr, int size) {
    for (int i = 0; i < size; i++) {
      cout << arr[i] << endl;
    }
  }
  int *copyarray(int og[], int inparr[], int size) {
    for (int i = 0; i < size; i++) {
      inparr[i] = og[i];
    }
    return inparr;
  };
  int arrayaddelementtoend(int arr[], int input, int size) {
    int temparr[size + 1];
    for (size_t i = 0; i < size; i++) {
      temparr[i] = arr[i];
    }
    temparr[size + 1] = 5;
  }
  int *addelemttoanyindex(int arr[], int size, int index, int var) {
    int temp[size + 1];
    for (int i = 0; i < size; i++) {
      if (i < index) {
        temp[i] = arr[i];
      } else {
        temp[i + 1] = arr[i];
      }
    }
    temp[index] = var;
    copyarray(temp, arr, size + 1);
    return arr;
  }
  void SetArray(int intarr) { array = intarr; }
  void SetSize(int ssize) { size = ssize; }
  int GetArray() { return array; }
  int GetSize() { return size; }
};
int main() {}